#ifndef STYLIZE_HPP
#define STYLIZE_HPP

#include <string>

std::string unstylize(std::string w);
std::string stylize(std::string w);

#endif 